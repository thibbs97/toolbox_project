Meeting 5: Data Science Team Building
Date: April 20th, 2023
Time: 12-12:45pm

Attendees:

- All members of the data science team

Agenda:

- Get to know each other better
- Discuss team goals and vision
- Brainstorm ways to improve team collaboration

Minutes:

- The team played a virtual game to get to know each other better and break the ice.
- Each team member shared their personal goals and how they align with the team's vision.
- The team discussed ways to improve collaboration, including setting up
